package com.cg.entity;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;

@Entity
public class Users implements Serializable{
	@Id
	@NotEmpty(message="User ID is mandatory")
	@Size(max=4,message="4 characters are required")
	private String user_id;
	@NotEmpty(message="Password is mandatory")
	@Size(min=7,max=15,message="maximum 15 and minumum 7 characters")
	@Pattern(regexp="[A-Za-z0-9@#&.]{7,15}" ,message="Your password should contain 1 Uppercase or 1 Special Character or 1 Number")
	private String password;
	@NotEmpty(message="Role is mandatory")
	@Pattern(regexp="[A-Z][a-z]{1,20}",message="first letter should be capital")
	private String role;
	@NotEmpty(message="User Name is mandatory")
	@Pattern(regexp="[A-Z][a-z]{3,20}",message="first letter should be capital")
	private String user_name;
	@NotEmpty(message="Phone Number is mandatory")
	@Pattern(regexp="[6-9]{1}[0-9]{9}",message="invalid mobile no")
	private String mobile_no;
	@NotEmpty(message="Phone Number is mandatory")
	@Pattern(regexp="[6-9]{1}[0-9]{9}",message="invalid mobile no")
	private String phone;
	@NotEmpty(message="Address is mandatory")
	@Pattern(regexp="[A-Za-z0-9., ]{5,50}",message="invalid Address")
	private String address;
	@NotEmpty(message="Email is mandatory")
	@Email(message = "Email should be valid")
	private String email;
	public String getUser_id() {
		return user_id;
	}
	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public String getUser_name() {
		return user_name;
	}
	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}
	public String getMobile_no() {
		return mobile_no;
	}
	public void setMobile_no(String mobile_no) {
		this.mobile_no = mobile_no;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public Users() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Users(String user_id, String password, String role,
			String user_name, String mobile_no, String phone, String address,
			String email) {
		super();
		this.user_id = user_id;
		this.password = password;
		this.role = role;
		this.user_name = user_name;
		this.mobile_no = mobile_no;
		this.phone = phone;
		this.address = address;
		this.email = email;
	}
	@Override
	public String toString() {
		return "Users [user_id=" + user_id + ", password=" + password
				+ ", role=" + role + ", user_name=" + user_name
				+ ", mobile_no=" + mobile_no + ", phone=" + phone
				+ ", address=" + address + ", email=" + email + "]";
	}
	
	
	


}
